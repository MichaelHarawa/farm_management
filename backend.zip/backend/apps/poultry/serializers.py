from __future__ import annotations
from decimal import Decimal
import uuid

from rest_framework import serializers

from .models import(
    Batch,
    BatchStatus,
    BatchWeightSample,
    BroilerStrain,
    BuyerType,
    ChicksSource,
    PaymentStatus,
    InputCosts,
    Sales,
    Mortality,
    FeedUsage,
    FlockAdjustment,
    DrugsVaccination,
)

class BatchSerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()
    broiler_strain = serializers.ChoiceField(
        choices=BroilerStrain.choices,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = Batch
        fields = (
            "id",
            "batch_id",
            "bird_type",
            "broiler_strain",
            "source",
            "source_other",
            "booking_date",
            "estimated_chick_arrival_date",
            "supplier_name",
            "booking_reference",
            "expected_quantity",
            "actual_quantity_received",
            "delivery_confirmed_at",
            "entry_date",
            "expected_maturity_date",
            "quantity",
            "status",
            "closed_at",
            "closure_reason",
            "profitability_finalized_at",
            "target_selling_price",
            "forecast_mortality_rate_percent",
            "estimated_remaining_feed_cost",
            "estimated_remaining_other_cost",
            "closure_notes",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )
        read_only_fields = (
            "id",
            "batch_id",
            "status",
            "delivery_confirmed_at",
            "closed_at",
            "closure_reason",
            "profitability_finalized_at",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )

    def validate(self, attrs):
        source = attrs.get("source", getattr(self.instance, "source", None))
        source_other_value = attrs.get(
            "source_other",
            getattr(self.instance, "source_other", ""),
        )
        source_other = (source_other_value or "").strip()

        if source == ChicksSource.OTHER and not source_other:
            raise serializers.ValidationError(
                {"source_other": "Enter the source name."}
            )

        attrs["source_other"] = (
            source_other if source == ChicksSource.OTHER else ""
        )

        return attrs

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""

        return obj.created_by.get_full_name() or obj.created_by.username


class BatchWeightSampleSerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()

    class Meta:
        model = BatchWeightSample
        fields = (
            "id",
            "batch",
            "age_in_days",
            "sampled_at",
            "sample_size",
            "average_weight_g",
            "notes",
            "reported_by_name",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )
        read_only_fields = (
            "id",
            "batch",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""
        return obj.created_by.get_full_name() or obj.created_by.username



class BatchStatusTransitionSerializer(serializers.Serializer):
    status = serializers.ChoiceField(
        choices=[
            (BatchStatus.DELIVERED, BatchStatus.DELIVERED.label),
        ]
    )


class BatchDeliverySerializer(serializers.Serializer):
    entry_date = serializers.DateTimeField()
    expected_maturity_date = serializers.DateTimeField(required=False)
    quantity = serializers.IntegerField(min_value=1, required=False)

    def validate(self, attrs):
        entry_date = attrs.get("entry_date")
        maturity_date = attrs.get("expected_maturity_date")

        if maturity_date and maturity_date <= entry_date:
            raise serializers.ValidationError(
                {
                    "expected_maturity_date": (
                        "Expected maturity date must be after the entry date."
                    )
                }
            )

        return attrs

class InputCostsSerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()
    direct_input_total = serializers.DecimalField(
        max_digits=14,
        decimal_places=2,
        read_only=True,
    )
    category = serializers.CharField(required=False, allow_blank=True)
    category_id = serializers.IntegerField(write_only=True, min_value=1, required=False)
    payment_status = serializers.ChoiceField(
        choices=[("paid", "Paid now"), ("credit", "Bought on credit")],
        write_only=True,
        default="credit",
    )
    funding_allocations = serializers.ListField(
        child=serializers.DictField(),
        write_only=True,
        required=False,
        default=list,
    )
    idempotency_key = serializers.CharField(
        write_only=True,
        max_length=120,
        default=lambda: str(uuid.uuid4()),
    )
    expenditure_reference = serializers.CharField(
        source="expenditure.expenditure_reference", read_only=True
    )
    expenditure_payment_status = serializers.CharField(
        source="expenditure.payment_status", read_only=True
    )
    expenditure_origin = serializers.CharField(source="expenditure.origin", read_only=True)
    amount_paid = serializers.SerializerMethodField()
    balance_due = serializers.SerializerMethodField()
    funding_sources = serializers.SerializerMethodField()

    class Meta:
        model = InputCosts
        fields = (
            "id",
            "batch",
            "expenditure",
            "expenditure_reference",
            "expenditure_payment_status",
            "expenditure_origin",
            "item",
            "category",
            "category_id",
            "quantity",
            "unit_measurement",
            "unit",
            "unit_cost",
            "usd_exchange_rate",
            "usd_equivalent",
            "direct_input_total",
            "purchase_date",
            "notes",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
            "amount_paid",
            "balance_due",
            "funding_sources",
            "payment_status",
            "funding_allocations",
            "idempotency_key",
        )
        read_only_fields = (
            "id",
            "batch",
            "expenditure",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
            "usd_equivalent",
            "direct_input_total",
            "expenditure_reference",
            "expenditure_payment_status",
            "expenditure_origin",
            "amount_paid",
            "balance_due",
            "funding_sources",
        )

    def validate(self, attrs):
        quantity = attrs.get("quantity", getattr(self.instance, "quantity", 0))
        unit = attrs.get("unit", getattr(self.instance, "unit", 0))
        unit_cost = attrs.get(
            "unit_cost",
            getattr(self.instance, "unit_cost", Decimal("0.00")),
        )

        errors = {}
        if quantity <= 0:
            errors["quantity"] = "Quantity must be greater than zero."
        if unit <= 0:
            errors["unit"] = "Unit must be greater than zero."
        if unit_cost < Decimal("0.00"):
            errors["unit_cost"] = "Unit cost cannot be negative."
        if not attrs.get("category_id"):
            from apps.finance.models import ExpenditureCategory

            category_name = (attrs.get("category") or "").strip()
            category = ExpenditureCategory.objects.filter(
                name__iexact=category_name,
                is_active=True,
            ).first()
            if category is None and "feed" in category_name.lower():
                category, _ = ExpenditureCategory.objects.get_or_create(
                    code="feed",
                    defaults={
                        "name": "Feed",
                        "default_accounting_nature": "direct_cost",
                        "requires_item_details": True,
                        "requires_batch_beneficiary": True,
                        "is_active": True,
                        "display_order": 20,
                    },
                )
            if category is None:
                errors["category_id"] = "Select a shared finance category."
            else:
                attrs["category_id"] = category.pk
        if errors:
            raise serializers.ValidationError(errors)

        return attrs

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""

        return obj.created_by.get_full_name() or obj.created_by.username

    def get_amount_paid(self, obj):
        if not obj.expenditure_id:
            return "0.00"
        from django.db.models import Sum
        return str(obj.expenditure.funding_allocations.aggregate(total=Sum("amount"))["total"] or Decimal("0.00"))

    def get_balance_due(self, obj):
        if not obj.expenditure_id:
            return str(obj.direct_input_total)
        return str(max(obj.expenditure.amount - Decimal(self.get_amount_paid(obj)), Decimal("0.00")))

    def get_funding_sources(self, obj):
        if not obj.expenditure_id:
            return []
        return [str(row.funding_source) for row in obj.expenditure.funding_allocations.select_related("funding_source")]


class BatchForecastAssumptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Batch
        fields = (
            "target_selling_price",
            "forecast_mortality_rate_percent",
            "estimated_remaining_feed_cost",
            "estimated_remaining_other_cost",
        )

    def validate_target_selling_price(self, value):
        if value is not None and value <= 0:
            raise serializers.ValidationError("Enter a selling price greater than zero.")
        return value

class SalesSerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()
    sale_total = serializers.DecimalField(
        max_digits=14,
        decimal_places=2,
        read_only=True,
    )

    class Meta:
        model = Sales
        fields = (
            "id",
            "batch",
            "sale_id",
            "sale_date",
            "due_date",
            "product_type",
            "quantity_sold",
            "unit_price",
            "usd_exchange_rate",
            "usd_equivalent",
            "sale_total",
            "buyer_name",
            "buyer_type",
            "buyer_type_other",
            "payment_status",
            "payment_method",
            "amount_paid",
            "balance",
            "receivable_follow_up_name",
            "sold_by_name",
            "notes",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )
        read_only_fields = (
            "id",
            "batch",
            "sale_id",
            "sale_total",
            "balance",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
            "usd_equivalent",
        )
        extra_kwargs = {
            "amount_paid": {"required": False},
        }

    def validate(self, attrs):
        quantity_sold = attrs.get(
            "quantity_sold",
            getattr(self.instance, "quantity_sold", 0),
        )
        unit_price = attrs.get(
            "unit_price",
            getattr(self.instance, "unit_price", Decimal("0.00")),
        )
        payment_status = attrs.get(
            "payment_status",
            getattr(self.instance, "payment_status", None),
        )
        amount_paid_supplied = "amount_paid" in attrs
        amount_paid = attrs.get(
            "amount_paid",
            getattr(self.instance, "amount_paid", Decimal("0.00")),
        )
        buyer_type = attrs.get(
            "buyer_type",
            getattr(self.instance, "buyer_type", None),
        )
        buyer_type_other = (
            attrs.get(
                "buyer_type_other",
                getattr(self.instance, "buyer_type_other", ""),
            )
            or ""
        ).strip()
        sale_total = (Decimal(quantity_sold) * unit_price).quantize(
            Decimal("0.01")
        )
        receivable_follow_up_name = (
            attrs.get(
                "receivable_follow_up_name",
                getattr(self.instance, "receivable_follow_up_name", ""),
            )
            or ""
        ).strip()

        errors = {}
        due_date = attrs.get("due_date", getattr(self.instance, "due_date", None))
        sale_date = attrs.get("sale_date", getattr(self.instance, "sale_date", None))
        if due_date and sale_date and due_date < sale_date.date():
            errors["due_date"] = "Payment due date cannot be before the sale date."
        if buyer_type == BuyerType.OTHER and len(buyer_type_other) < 2:
            errors["buyer_type_other"] = (
                "Other buyer type must contain at least 2 characters."
            )
        attrs["buyer_type_other"] = (
            buyer_type_other if buyer_type == BuyerType.OTHER else ""
        )
        if payment_status == PaymentStatus.PAID:
            amount_paid = sale_total
            attrs["amount_paid"] = sale_total
        elif self.instance is None and not amount_paid_supplied:
            errors["amount_paid"] = "Amount paid is required unless the sale is paid."
        if quantity_sold <= 0:
            errors["quantity_sold"] = "Quantity sold must be greater than zero."
        if unit_price < Decimal("0.00"):
            errors["unit_price"] = "Unit price cannot be negative."
        if amount_paid < Decimal("0.00"):
            errors["amount_paid"] = "Amount paid cannot be negative."
        if (
            payment_status != PaymentStatus.CANCELLED
            and amount_paid > sale_total
        ):
            errors["amount_paid"] = "Amount paid cannot exceed sale total."
        outstanding_balance = (
            Decimal("0.00")
            if payment_status == PaymentStatus.CANCELLED
            else max(sale_total - amount_paid, Decimal("0.00"))
        )
        if outstanding_balance > Decimal("0.00"):
            if len(receivable_follow_up_name) < 2:
                errors["receivable_follow_up_name"] = (
                    "Enter the person responsible for following up the remaining amount."
                )
            attrs["receivable_follow_up_name"] = receivable_follow_up_name
        else:
            attrs["receivable_follow_up_name"] = ""
        if errors:
            raise serializers.ValidationError(errors)

        return attrs

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""

        return obj.created_by.get_full_name() or obj.created_by.username

class MortalitySerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()

    class Meta:
        model = Mortality
        fields= (
                "id",
                "batch",
                "mortality_date",
                "quantity_dead",
                "age_in_days",
                "suspected_cause",
                "description",
                "action_taken",
                "reported_by_name",
                "created_at",
                "updated_at",
                "created_by",
                "created_by_name",
        )
        read_only_fields = (
            "id",
            "batch",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""

        return obj.created_by.get_full_name() or obj.created_by.username

class FeedUsageSerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()
    feed_quantity_kg = serializers.DecimalField(
        source="quantity_kg", max_digits=14, decimal_places=3, read_only=True
    )
    feed_per_live_bird_at_event = serializers.DecimalField(
        max_digits=14, decimal_places=4, read_only=True, allow_null=True
    )
    population_ordering_rule = serializers.SerializerMethodField()

    class Meta:
        model = FeedUsage
        fields = (
                "id",
                "batch",
                "initial_age",
                "feeding_start_date",
                "feeding_end_date",
                "feed_type",
                "feed_source",
                "quantity_given",
                "unit_of_measurement",
                "current_number_of_birds",
                "feed_quantity_kg",
                "feed_per_live_bird_at_event",
                "population_calculation_version",
                "population_calculated_at",
                "population_ordering_rule",
                "notes",
                "reported_by_name",
                "created_at",
                "updated_at",
                "created_by",
                "created_by_name",

        )
        read_only_fields = (
            "id",
            "batch",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
            "current_number_of_birds",
            "population_calculation_version",
            "population_calculated_at",
        )

    def validate(self, attrs):
        start = attrs.get("feeding_start_date")
        end = attrs.get("feeding_end_date")
        if start and end and end < start:
            raise serializers.ValidationError(
                {"feeding_end_date": "Feeding end cannot be before feeding start."}
            )
        return attrs

    def get_population_ordering_rule(self, obj):
        from apps.poultry.services.feed_metrics import SAME_TIMESTAMP_ORDERING

        return SAME_TIMESTAMP_ORDERING

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""

        return obj.created_by.get_full_name() or obj.created_by.username


class FlockAdjustmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = FlockAdjustment
        fields = (
            "id",
            "batch",
            "effective_at",
            "quantity_change",
            "reason",
            "status",
            "approved_by",
            "created_at",
        )
        read_only_fields = ("id", "batch", "status", "approved_by", "created_at")

class DrugsVaccinationSerializer(serializers.ModelSerializer):
    created_by_name = serializers.SerializerMethodField()

    class Meta:
        model = DrugsVaccination
        fields = (
                "id",
                "batch",
                "vaccination_date",
                "drug_vaccination_type",
                "other_drug_vaccination",
                "drug_category",
                "quantity",
                "description",
                "timely_status",
                "reported_by_name",
                "created_at",
                "updated_at",
                "created_by",
                "created_by_name",

        )
        read_only_fields = (
            "id",
            "batch",
            "created_at",
            "updated_at",
            "created_by",
            "created_by_name",
        )

    def get_created_by_name(self, obj):
        if obj.created_by_id is None:
            return ""

        return obj.created_by.get_full_name() or obj.created_by.username


