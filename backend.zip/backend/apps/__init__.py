"""Farmnotes application packages."""
